package objetos;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Mesas {
    public static Scanner scan = new Scanner(System.in);
    public static List<Mesas> listaMesas = new ArrayList<>();
    private int codMesa;
    private int capacidade;
    private boolean disponibilidade;

    public Mesas(int codMesa, int capacidade, boolean disponibilidade) {
        this.codMesa = codMesa;
        this.capacidade = capacidade;
        this.disponibilidade = disponibilidade;
    }

    public int getCodMesa() {
        return codMesa;
    }

    public void setCodMesa(int codMesa) {
        this.codMesa = codMesa;
    }

    public int getCapacidade() {
        return capacidade;
    }

    public void setCapacidade(int capacidade) {
        this.capacidade = capacidade;
    }

    public boolean isDisponibilidade() {
        return disponibilidade;
    }

    public void setDisponibilidade(boolean disponibilidade) {
        this.disponibilidade = disponibilidade;
    }

    public static void criarMesa() {
        int codMesa, capacidade, op;
        boolean disponibilidade = true;
        System.out.println("Digite o código da mesa:");
        codMesa = scan.nextInt();
        System.out.println("Digite a capacidade da mesa:");
        capacidade = scan.nextInt();
        System.out.println("Deseja já reservar a mesa - 1 sim, 2 não");
        op = scan.nextInt();
        if (op == 1) {
            disponibilidade = false;
            System.out.println("A mesa está reservada.");
        } else {
            System.out.println("A mesa está disponível.");
        }

        // Adiciona a mesa criada à lista
        listaMesas.add(new Mesas(codMesa, capacidade, disponibilidade));
    }

    @Override
    public String toString() {
        return "Código da mesa: " + codMesa + ", capacidade: " + capacidade + ", disponibilidade: " + disponibilidade;
    }

    public void modMesa() {
        int codMesaBusca, capacidadeBusca, op;
        System.out.println("Deseja realizar a busca pela capacidade ou código da mesa: - 1 capacidade, 2 código");
        op = scan.nextInt();

        if (op == 1) {
            System.out.println("Digite a capacidade da mesa:");
            capacidadeBusca = scan.nextInt();
            boolean mesaEncontrada = false;

            for (Mesas mesa : listaMesas) {
                if (mesa.getCapacidade() == capacidadeBusca) {
                    System.out.println(mesa.toString());
                    mesaEncontrada = true;
                }
            }

            if (!mesaEncontrada) {
                System.out.println("Nenhuma mesa encontrada com essa capacidade.");
            }

        } else if (op == 2) {
            System.out.println("Digite o código da mesa:");
            codMesaBusca = scan.nextInt();
            boolean mesaEncontrada = false;

            for (Mesas mesa : listaMesas) {
                if (mesa.getCodMesa() == codMesaBusca) {
                    System.out.println(mesa.toString());
                    mesaEncontrada = true;
                }
            }

            if (!mesaEncontrada) {
                System.out.println("Nenhuma mesa encontrada com esse código.");
            }

        } else {
            System.out.println("Opção inválida.");
        }
    }
    public static void inicializarMesas() {
        listaMesas.add(new Mesas(1, 4, true));
        listaMesas.add(new Mesas(2, 2, true));
        listaMesas.add(new Mesas(3, 6, true)); 
        listaMesas.add(new Mesas(4, 4, true));
        listaMesas.add(new Mesas(5, 2, true)); 
    }
}
