package objetos;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Cardapio {
    public static Scanner scan = new Scanner(System.in);
    public static List<Cardapio> listaCard = new ArrayList<>(); // Tornar esta lista estática

    private int codCard;
    private String nomePrato;
    private double preco;
    private boolean disponibilidade;

    public Cardapio(int codCard, String nomePrato, double preco, boolean disponibilidade) {
        this.codCard = codCard;
        this.nomePrato = nomePrato;
        this.preco = preco;
        this.disponibilidade = disponibilidade;
    }

    public int getCodCard() {
        return codCard;
    }

    public String getNomePrato() {
        return nomePrato;
    }

    public double getPreco() {
        return preco;
    }

    public boolean isDisponibilidade() {
        return disponibilidade;
    }

    public void setDisponibilidade(boolean disponibilidade) {
        this.disponibilidade = disponibilidade;
    }

    public String toString() {
        return "Código: " + codCard + ", Nome do prato: " + nomePrato + ", Preço: R$ " + preco + ", Disponibilidade: " + (disponibilidade ? "Disponível" : "Indisponível");
    }

    public static void criarCard() {
        System.out.println("Digite o código do prato:");
        int codCard = scan.nextInt();
        scan.nextLine(); // Consumir a nova linha
        System.out.println("Digite o nome do prato:");
        String nomePrato = scan.nextLine();
        System.out.println("Digite o preço do prato:");
        double preco = scan.nextDouble();
        System.out.println("O prato está disponível? (sim/não)");
        String disp = scan.next();

        boolean disponibilidade = disp.equalsIgnoreCase("sim");
        Cardapio cardapio = new Cardapio(codCard, nomePrato, preco, disponibilidade);
        listaCard.add(cardapio);
    }

    public static void listarCard() {
        if (listaCard.isEmpty()) {
            System.out.println("Nenhum prato cadastrado.");
        } else {
            for (Cardapio cardapio : listaCard) {
                System.out.println(cardapio.toString());
            }
        }
    }

    public static Cardapio buscarPrato(int codPrato) {
        for (Cardapio prato : listaCard) {
            if (prato.getCodCard() == codPrato) {
                return prato;
            }
        }
        return null; // Retorna nulo se não encontrar
    }
    public static void inicializarCardapio() {
        listaCard.add(new Cardapio(1, "Pizza", 30.00, true));
        listaCard.add(new Cardapio(2, "Hambúrguer", 25.00, true));
        listaCard.add(new Cardapio(3, "Salada", 15.00, true));
        listaCard.add(new Cardapio(4, "Refrigerante", 5.00, true));
        listaCard.add(new Cardapio(5, "Cerveja", 10.00, true));
        listaCard.add(new Cardapio(6, "Frango Frito", 28.00, true));
    }
}
