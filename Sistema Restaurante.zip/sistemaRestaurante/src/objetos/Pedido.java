package objetos;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Pedido{
    public static Scanner scan = new Scanner(System.in);
    public static List<Pedido> listaPedidos = new ArrayList<>();
    
    private Mesas mesa;
    private Funcionarios garcom;
    private List<Cardapio> itens; // Itens do pedido
    private double valorTotal;
    private boolean contaFechada;

    public Pedido(Mesas mesa, Funcionarios garcom) {
        this.mesa = mesa;
        this.garcom = garcom;
        this.itens = new ArrayList<>();
        this.valorTotal = 0.0;
        this.contaFechada = false; // Inicialmente, a conta não está fechada
    }

    public void adicionarItem(Cardapio prato) {
        System.out.println("Verificando disponibilidade do prato: " + prato.getNomePrato() + ", Disponível: " + prato.isDisponibilidade());
        
        if (prato.isDisponibilidade()) {
            itens.add(prato);
            valorTotal += prato.getPreco();
            prato.setDisponibilidade(false); // O prato agora está indisponível
            
            // Registrar venda no garçom
            garcom.registrarVenda(prato.getPreco());
            System.out.println("Item adicionado: " + prato.getNomePrato());
        } else {
            System.out.println("O prato " + prato.getNomePrato() + " não está disponível.");
        }
    }

    public void finalizarPedido() {
        listaPedidos.add(this);
        System.out.println("Pedido finalizado.");
        System.out.println("Mesa: " + mesa.getCodMesa() + ", Garçom: " + garcom.getNome() + ", Total: R$ " + String.format("%.2f", valorTotal));
    }

    public void fecharConta() {
        if (!contaFechada) {
            contaFechada = true; // Marca o pedido como fechado
            mesa.setDisponibilidade(true); // Libera a mesa
            System.out.println("Conta fechada. Valor total a pagar: R$ " + String.format("%.2f", valorTotal));
        } else {
            System.out.println("A conta já foi fechada.");
        }
    }

    public static void registrarPedido(Mesas mesa, Funcionarios garcom) {
        Pedido pedido = new Pedido(mesa, garcom);
        
        int codPrato;
        do {
            System.out.println("Selecione um prato do cardápio:");
            Cardapio.listarCard(); // Método que lista os pratos disponíveis
            System.out.print("Digite o código do prato para adicionar ao pedido ou 0 para finalizar: ");
            codPrato = scan.nextInt();
            
            if (codPrato == 0) {
                pedido.finalizarPedido();
                return;
            }

            // Verificar se o prato existe
            Cardapio pratoSelecionado = Cardapio.buscarPrato(codPrato);
            
            if (pratoSelecionado != null) {
                pedido.adicionarItem(pratoSelecionado);
            } else {
                System.out.println("Prato não encontrado. Tente novamente.");
            }
        } while (true);
    }

    public static void relatorioFaturamentoDiario() {
        double totalVendas = 0;
        System.out.println("Relatório de Faturamento Diário:");
        
        for (Pedido pedido : listaPedidos) {
            if (pedido.contaFechada) {
                totalVendas += pedido.valorTotal;
                System.out.printf("Mesa: %d, Total: R$ %.2f, Garçom: %s%n", pedido.mesa.getCodMesa(), pedido.valorTotal, pedido.garcom.getNome());
            }
        }
        
        System.out.printf("Total de vendas realizadas no dia: R$ %.2f%n", totalVendas);
    }

    public static void relatorioVendasPorGarcom(Funcionarios garcom) {
        garcom.relatorioVendas();
    }

    // Métodos adicionais para acessar os dados do pedido
    public boolean isFechado() {
        return contaFechada;
    }

    public double getValorTotal() {
        return valorTotal;
    }

    public Mesas getMesa() {
        return mesa;
    }

    public Funcionarios getGarcom() {
        return garcom;
    }
}
