package objetos;

import java.util.List;

public class Faturamento {
    // Total de vendas realizadas no dia
    public static double totalVendas(List<Pedido> pedidos) {
        double total = 0;
        for (Pedido pedido : pedidos) {
            if (pedido.isFechado()) {  // Verifica se a conta está fechada
                total += pedido.getValorTotal();  // Soma o valor total do pedido
            }
        }
        return total;  // Retorna o total de vendas
    }
 
        
    // Total de vendas por mesa
    public static void vendasPorMesa(List<Pedido> pedidos) {
        System.out.println("Vendas por Mesa:");
        double[] totalPorMesa = new double[100]; // Array para acumular valores por mesa (assumindo até 100 mesas)

        for (Pedido pedido : pedidos) {
            if (pedido.isFechado()) {  // Verifica se a conta está fechada
                int mesaId = pedido.getMesa().getCodMesa(); // Usa o código da mesa
                totalPorMesa[mesaId] += pedido.getValorTotal(); // Acumula o total para a mesa
            }
        }

        for (int i = 0; i < totalPorMesa.length; i++) {
            if (totalPorMesa[i] > 0) {
                System.out.printf("Mesa %d: R$ %.2f%n", i, totalPorMesa[i]); // Imprime o total por mesa
            }
        }
    }

    // Total de vendas por garçom
    public static void vendasPorGarcom(List<Pedido> pedidos) {
        System.out.println("Vendas por Garçom:");
        double[] totalPorGarcom = new double[100]; // Array para acumular valores por garçom (assumindo até 100 garçons)
        String[] nomesGarcom = new String[100]; // Array para armazenar nomes dos garçons

        for (Pedido pedido : pedidos) {
            if (pedido.isFechado()) {  // Verifica se a conta está fechada
                String nomeGarcom = pedido.getGarcom().getNome(); // Obtém o nome do garçom
                int index = -1;

                // Verifica se o garçom já foi registrado
                for (int i = 0; i < nomesGarcom.length; i++) {
                    if (nomesGarcom[i] != null && nomesGarcom[i].equals(nomeGarcom)) {
                        index = i;
                        break;
                    }
                }

                // Se não foi registrado, encontra um índice livre
                if (index == -1) {
                    for (int i = 0; i < nomesGarcom.length; i++) {
                        if (nomesGarcom[i] == null) {
                            nomesGarcom[i] = nomeGarcom; // Armazena o nome do garçom
                            index = i;
                            break;
                        }
                    }
                }

                totalPorGarcom[index] += pedido.getValorTotal(); // Acumula o total para o garçom
            }
        }

        for (int i = 0; i < totalPorGarcom.length; i++) {
            if (totalPorGarcom[i] > 0) {
                System.out.printf("Garçom %s: R$ %.2f%n", nomesGarcom[i], totalPorGarcom[i]); // Imprime o total por garçom
            }
        }
    }

    // Relatório completo
    public static void gerarRelatorio(List<Pedido> pedidos) {
        System.out.println("Relatório de Faturamento do Dia:");
        System.out.printf("Total de vendas: R$ %.2f%n", totalVendas(pedidos)); // Total de vendas do dia
        vendasPorMesa(pedidos); // Chama o método para vendas por mesa
        vendasPorGarcom(pedidos); // Chama o método para vendas por garçom
    }
   

}
