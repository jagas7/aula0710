package objetos;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

public class Funcionarios {
    public static Scanner scan = new Scanner(System.in);
    public static List<Funcionarios> listaFun = new ArrayList<>();
    
    private String nome;
    private int codFun;
    private String cargo;
    private int totalVendas;
    private double valorTotalVendas;

    public Funcionarios(String nome, int codFun, String cargo) {
        this.nome = nome;
        this.codFun = codFun;
        this.cargo = cargo;
        this.totalVendas = 0;
        this.valorTotalVendas = 0.0; 
    }
    
    public static Scanner getScan() {
        return scan;
    }

    public static void setScan(Scanner scan) {
        Funcionarios.scan = scan;
    }

    public String getNome() {
        return nome;
    }

    public int getCodFun() {
        return codFun;
    }

    public String getCargo() {
        return cargo;
    }

    public int getTotalVendas() {
        return totalVendas;
    }
    
    public void registrarVenda(double valor) {
        this.totalVendas++;
        this.valorTotalVendas += valor;
    }

    public void relatorioVendas() {
        System.out.println("Nome do Funcionário: " + nome);
        System.out.println("Total de Pedidos Realizados: " + totalVendas);
        System.out.printf("Valor Total Vendido: R$ %.2f%n", valorTotalVendas);
    }

    public static void criarFun() {
        System.out.println("Você adicionará um funcionário à lista FUNCIONARIOS");
        System.out.print("Digite o Id do funcionário: ");
        int codFun = scan.nextInt();
        scan.nextLine(); // Limpar o buffer
        
        System.out.print("Digite o nome do funcionário: ");
        String nome = scan.nextLine();
        
        System.out.print("Digite o cargo do funcionário (Garçom, Cozinheiro, Gerente): ");
        String cargo = scan.nextLine();

        Funcionarios funcionario = new Funcionarios(nome, codFun, cargo);
        listaFun.add(funcionario);

        System.out.println("Funcionário Adicionado à lista: " + funcionario);
    }
    
    @Override
    public String toString() {
        String result = "Código do funcionário: " + codFun + ", Nome: " + nome + ", Cargo: " + cargo;
        result += (cargo.equalsIgnoreCase("garcom") || cargo.equalsIgnoreCase("garçom")) ? 
                  ", Total de vendas: " + totalVendas : "";
        return result;
    }

    public static void modLisFun() {
        if (listaFun.isEmpty()) {
            System.out.println("Nenhum funcionário cadastrado.");
            return; 
        }

        int op;
        System.out.println("Deseja realizar a busca pelo: 1 - código ou 2 - nome?");
        op = scan.nextInt();
        scan.nextLine(); 

        if (op == 1) {
            System.out.print("Digite o código do funcionário: ");
            int codBusca = scan.nextInt();
            scan.nextLine();
            
            Funcionarios funcionarioEncontrado = null;
            for (Funcionarios funcionario : listaFun) {
                if (funcionario.getCodFun() == codBusca) {
                    funcionarioEncontrado = funcionario;
                    break;
                }
            }

            if (funcionarioEncontrado != null) {
                System.out.println(funcionarioEncontrado);
                System.out.print("Deseja excluir esse funcionário? 1 - Sim, 2 - Não: ");
                int opex = scan.nextInt();
                if (opex == 1) {
                    listaFun.remove(funcionarioEncontrado);
                    System.out.println("Funcionário excluído com sucesso.");
                } else {
                    System.out.println("Funcionário não foi excluído.");
                }
            } else {
                System.out.println("Funcionário com código " + codBusca + " não encontrado.");
            }
        } else if (op == 2) {
            System.out.print("Digite o nome do funcionário: ");
            String nomeBusca = scan.nextLine();
            
            Funcionarios funcionarioEncontrado = null;
            for (Funcionarios funcionario : listaFun) {
                if (funcionario.getNome().equalsIgnoreCase(nomeBusca)) {
                    funcionarioEncontrado = funcionario;
                    break;
                }
            }

            if (funcionarioEncontrado != null) {
                System.out.println(funcionarioEncontrado);
                System.out.print("Deseja excluir esse funcionário? 1 - Sim, 2 - Não: ");
                int opex = scan.nextInt();
                if (opex == 1) {
                    listaFun.remove(funcionarioEncontrado);
                    System.out.println("Funcionário excluído com sucesso.");
                } else {
                    System.out.println("Funcionário não foi excluído.");
                }
            } else {
                System.out.println("Funcionário com nome " + nomeBusca + " não encontrado.");
            }
        } else {
            System.out.println("Opção inválida.");
        }
    }
  
    public static void listarFun() {
        if (listaFun.isEmpty()) {
            System.out.println("Nenhum funcionário cadastrado.");
        } else {
            for (Funcionarios funcionario : listaFun) {
                System.out.println(funcionario);
            }
        }
    }
    public static void inicializarFuncionarios() {
        listaFun.add(new Funcionarios("Maria",1,"garcom"));
        
    }
}
