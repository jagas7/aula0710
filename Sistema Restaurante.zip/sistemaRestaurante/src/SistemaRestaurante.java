import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import objetos.Cardapio;
import objetos.Funcionarios;
import objetos.Mesas;
import objetos.Pedido;
import objetos.Faturamento;

public class SistemaRestaurante {
    public static Scanner scan = new Scanner(System.in);

    public static void main(String[] args) {
    	 Mesas.inicializarMesas();
    	 Funcionarios.inicializarFuncionarios();
    	 Cardapio.inicializarCardapio();
        while (true) {
            System.out.println("Bem-vindo ao Sistema do Restaurante");
            System.out.println("Escolha uma opção:");
            System.out.println("1 - Adicionar Funcionário");
            System.out.println("2 - Adicionar Mesa");
            System.out.println("3 - Adicionar Prato ao Cardápio");
            System.out.println("4 - Registrar Pedido");
            System.out.println("5 - Fechar Conta");
            System.out.println("6 - Relatório de Faturamento Diário");
            System.out.println("7 - Relatório de Vendas por Funcionário");
            System.out.println("0 - Sair");
            int opcao = scan.nextInt();

            switch (opcao) {
                case 1:
                    Funcionarios.criarFun(); 
                    break;
                case 2:
                    Mesas.criarMesa(); 
                    break;
                case 3:
                    Cardapio.criarCard();
                    break;
                case 4:
                    
                    System.out.println("Mesas disponíveis:");
                    boolean encontrouMesaDisponivel = false;

                    for (Mesas mesa : Mesas.listaMesas) { 
                        if (mesa.isDisponibilidade()) {
                            System.out.println(mesa.toString());
                            encontrouMesaDisponivel = true;
                        }
                    }

                    if (!encontrouMesaDisponivel) {
                        System.out.println("Não há mesas disponíveis no momento.");
                    } else {
                        System.out.print("Digite o código da mesa: ");
                        int codMesa = scan.nextInt();
                        Mesas mesaSelecionada = null;

                        
                        for (Mesas mesa : Mesas.listaMesas) {
                            if (mesa.getCodMesa() == codMesa) {
                                mesaSelecionada = mesa;
                                break;
                            }
                        }

                        if (mesaSelecionada != null) {
                         
                            if (mesaSelecionada.isDisponibilidade()) {
                                
                                Funcionarios.listarFun();
                                System.out.print("Digite o código do garçom: ");
                                int codGarcom = scan.nextInt();
                                Funcionarios garcomSelecionado = null;

                               
                                for (Funcionarios funcionario : Funcionarios.listaFun) {
                                    if (funcionario.getCodFun() == codGarcom) {
                                        garcomSelecionado = funcionario;
                                        break;
                                    }
                                }

                                if (garcomSelecionado != null) {
                                    Pedido.registrarPedido(mesaSelecionada, garcomSelecionado);
                                } else {
                                    System.out.println("Garçom não encontrado. Tente novamente.");
                                }
                            } else {
                                System.out.println("Mesa não está disponível.");
                            }
                        } else {
                            System.out.println("Mesa não encontrada.");
                        }
                    }
                    break;

                case 5:
        
                  System.out.print("Digite o código da mesa para fechar a conta: ");
                    int codMesaFechar = scan.nextInt();
                    boolean mesaEncontrada = false;

                    for (Mesas mesa : Mesas.listaMesas) {
                        if (mesa.getCodMesa() == codMesaFechar) {
                            mesaEncontrada = true;
                            for (Pedido pedido : Pedido.listaPedidos) {
                                if (pedido.getMesa().getCodMesa() == codMesaFechar && !pedido.isFechado()) {
                                    pedido.fecharConta();
                                    System.out.println("Conta fechada com sucesso para a mesa " + codMesaFechar);
                                    break;
                                }
                            }
                            break; 
                        }
                    }

                    if (!mesaEncontrada) {
                        System.out.println("Mesa não encontrada.");
                    }
                    break;



                case 6:
                    List<Pedido> pedidosFechados = new ArrayList<>(); 

                   
                    for (Pedido pedido : Pedido.listaPedidos) {
                        if (pedido.isFechado()) { 
                            pedidosFechados.add(pedido); 
                        }
                    }

                    if (pedidosFechados.isEmpty()) {
                        System.out.println("Não há pedidos fechados para gerar o relatório.");
                    } else {
                  
                        System.out.println("Relatório de Pedidos Fechados:");
                        for (Pedido pedido : pedidosFechados) {
                            System.out.println("Mesa " + pedido.getMesa().getCodMesa() + ", Total: R$ " + String.format("%.2f", pedido.getValorTotal()));
                        }
                        Faturamento.gerarRelatorio(pedidosFechados); 
                    }
                    break;


                case 7:
                    Funcionarios.modLisFun(); 
                    break;
                case 0:
                    System.out.println("Saindo do sistema...");
                    return;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }
        }
    }
}
